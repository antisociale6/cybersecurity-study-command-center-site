# Authorized Security Lab Command Checklist

Use this checklist to keep useful commands and evidence together while working
in a controlled cybersecurity lab.

## Authorization boundary

Use these commands only on systems you own or are explicitly authorized to
test. Write down the approved target and scope before starting. Stop if the
target, time window, or permitted technique is unclear. Never scan public IPs,
domains, school networks, workplace systems, or third-party services without
specific permission.

## Before the lab

- Approved target or lab name: `________________________________`
- Evidence of permission or ownership: `________________________`
- Allowed techniques: `_________________________________________`
- Stop time or condition: `_____________________________________`
- Evidence folder: `____________________________________________`

Use `<authorized-target>` below only after completing that scope record.

## Service discovery

- `nmap -sV -sC <authorized-target>` — identify common services using standard
  scripts inside the approved scope.
- `nmap -p- <authorized-target>` — check all TCP ports only when the lab rules
  permit a full-port scan.
- `whatweb http://<authorized-target>` — note web technologies on an approved
  local or training web target.

Record the exact command, start time, end time, result, and any error. Do not
increase scan speed or add intrusive scripts unless the lab instructions
explicitly allow it.

## Evidence to capture

- A before screenshot showing the controlled lab target.
- The exact command and its purpose.
- The relevant output, with secrets and personal data removed.
- What the result means and what it does **not** prove.
- A cleanup or reset note for the lab environment.

## Portfolio prompt

Use this factual structure after each lab:

> In an authorized training environment, I used `<tool>` to examine
> `<approved target>`, observed `<finding>`, and preserved `<evidence>`. The
> exercise demonstrated `<specific skill>`; it did not test a live production
> system.

Do not include real credentials, private IP information from other people,
customer data, or claims you cannot support with your own evidence.

## Continue with the complete system

The **Cybersecurity Study Command Center Membership** is €9 per month for 12 months.
It adds the complete lab-notes vault, command library, progress tracking,
project-evidence templates, portfolio write-up structure, and 12 defensive
security sprints. It is a self-guided educational resource, not certification,
employment, income, or security-outcome assurance.

Review the complete system and its current terms before deciding:
https://antisociale6.github.io/cybersecurity-study-command-center-site/?utm_source=free-checklist&utm_medium=lead-magnet&utm_campaign=membership-checklist-upgrade
